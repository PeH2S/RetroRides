{{-- resources/views/pages/favoritos/index.blade.php --}}
@extends('static.layoutHome')
@section('main')
  <div class="container mt-4">
    <h2>Favoritos</h2>
    <p>Ainda não implementado.</p>
  </div>
@endsection

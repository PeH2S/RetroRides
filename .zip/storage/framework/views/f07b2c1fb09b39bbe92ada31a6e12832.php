<?php $__env->startSection('title', 'Minha Conta'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1 class="mb-4">Minha Conta</h1>

  <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <form action="<?php echo e(route('minha-conta.update')); ?>" method="POST" novalidate>
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row g-4">
      
      <div class="col-lg-6">
        <div class="card shadow-sm h-100">
          <div class="card-header">
            <h5 class="mb-1">Meus Dados</h5>
            <small class="text-muted">* Campos obrigatórios</small>
          </div>
          <div class="card-body">
            
            <div class="mb-3">
              <label for="email" class="form-label">E-mail *</label>
              <input type="email"
                     name="email"
                     id="email"
                     class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('email', $user->email)); ?>"
                     required>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-3">
              <label for="name" class="form-label">Nome Completo *</label>
              <input type="text"
                     name="name"
                     id="name"
                     class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('name', $user->name)); ?>"
                     required>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-3">
              <label for="gender" class="form-label">Gênero *</label>
              <select name="gender"
                      id="gender"
                      class="form-select <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      required>
                <option disabled value="" <?php echo e(old('gender',$user->gender)?'':'selected'); ?>>Selecione</option>
                <option value="masculino" <?php echo e(old('gender',$user->gender)=='masculino'?'selected':''); ?>>Masculino</option>
                <option value="feminino"  <?php echo e(old('gender',$user->gender)=='feminino'?'selected':''); ?>>Feminino</option>
                <option value="outro"      <?php echo e(old('gender',$user->gender)=='outro'?'selected':''); ?>>Outro</option>
              </select>
              <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-3">
              <label for="birthdate" class="form-label">Data de Nascimento *</label>
              <input type="date"
                     name="birthdate"
                     id="birthdate"
                     class="form-control <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('birthdate', optional($user->birthdate)->format('Y-m-d'))); ?>"
                     required>
              <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-3">
              <label for="cpf" class="form-label">CPF *</label>
              <input type="text"
                     name="cpf"
                     id="cpf"
                     class="form-control <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('cpf', $user->cpf)); ?>"
                     placeholder="000.000.000-00"
                     required>
              <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <small class="text-muted">Ao prosseguir, declaro ter ter 18 anos ou mais.</small>
          </div>
        </div>
      </div>

      
      <div class="col-lg-6">
        <div class="card shadow-sm h-100">
          <div class="card-header">
            <h5 class="mb-1">Endereço e Contato</h5>
            <small class="text-muted">* Campos obrigatórios</small>
          </div>
          <div class="card-body">
            
            <div class="mb-3">
              <label for="cep" class="form-label">CEP *</label>
              <input type="text"
                     name="cep"
                     id="cep"
                     class="form-control <?php $__errorArgs = ['cep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('cep', $user->address->cep ?? '')); ?>"
                     placeholder="00000-000"
                     required>
              <?php $__errorArgs = ['cep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="row g-2 mb-3">
              <div class="col-md-4">
                <label for="state" class="form-label">Estado *</label>
                <input type="text"
                       name="state"
                       id="state"
                       class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('state', $user->address->state ?? '')); ?>"
                       placeholder="SP"
                       required>
                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-md-8">
                <label for="city" class="form-label">Cidade *</label>
                <input type="text"
                       name="city"
                       id="city"
                       class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('city', $user->address->city ?? '')); ?>"
                       placeholder="São Paulo"
                       required>
                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            
            <div class="mb-3">
              <label for="phone" class="form-label">Telefone *</label>
              <div class="input-group">
                <input type="text"
                       name="phone"
                       id="phone"
                       class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('phone', $user->phone)); ?>"
                       placeholder="(00) 00000-0000"
                       required>
                <button type="button" class="btn btn-outline-secondary" id="btn-edit-phone">Editar</button>
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <small class="form-text text-muted mt-1">
                Próxima alteração de celular só após 24h.
              </small>
            </div>

            
            <div class="form-check mb-3">
              <input class="form-check-input"
                     type="checkbox"
                     id="show_phone"
                     name="show_phone"
                     value="1"
                     <?php echo e(old('show_phone', $user->show_phone ?? false) ? 'checked' : ''); ?>>
              <label class="form-check-label" for="show_phone">
                Exibir meu telefone no anúncio
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div class="mt-4 d-grid">
      <button type="submit" class="btn btn-danger btn-lg">Salvar Alterações</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    // Máscaras
    const applyMask = (selector, maskPattern) => {
      const el = document.querySelector(selector);
      if (!el) return;
      el.addEventListener('input', () => {
        let v = el.value.replace(/\D/g, '');
        el.value = v
          .replace(new RegExp(maskPattern.replace(/0/g, '\\d')),
                   (matches) => {
                     let result = maskPattern;
                     matches.split('').forEach((d, i) => {
                       result = result.replace('0', d);
                     });
                     return result;
                   })
          .substring(0, maskPattern.length);
      });
    };

    applyMask('#cep', '00000-000');
    applyMask('#cpf', '000.000.000-00');
    applyMask('#phone', '(00) 00000-0000');
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/account/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main'); ?>
<div class="container mt-4">
    <h2>Meus Anúncios</h2>
    <?php if($meusAnuncios->isEmpty()): ?>
        <p>Você ainda não publicou nenhum anúncio.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $meusAnuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($anuncio->id); ?></td>
                        <td><?php echo e($anuncio->titulo); ?></td>
                        <td><?php echo e($anuncio->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('anuncio.show', $anuncio->id)); ?>" class="btn btn-sm btn-info">
                                Ver
                            </a>
                            
                            <a href="<?php echo e(route('anuncio.edit', $anuncio->id)); ?>" class="btn btn-sm btn-warning">
                                Editar
                            </a>
                            
                            <form action="<?php echo e(route('anuncio.destroy', $anuncio->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger"
                                        onclick="return confirm('Deseja mesmo excluir este anúncio?')">
                                    Excluir
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($meusAnuncios->links()); ?>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/anuncios/meus.blade.php ENDPATH**/ ?>
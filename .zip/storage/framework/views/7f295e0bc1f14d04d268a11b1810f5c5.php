<?php $__env->startSection('main'); ?>
<div class="container-fluid">
  <div class="row">
    
    <div class="col-md-3 bg-light border-end vh-100 p-0">
      <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div class="col-md-9 p-4">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>
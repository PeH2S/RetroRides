<?php $__env->startSection('main'); ?>
<div class="container mt-4">
  <div class="row">
    
    <div class="col-md-8">
      <div id="anuncioCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <?php $__currentLoopData = $anuncio->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($i === 0 ? 'active' : ''); ?>">
              <img src="<?php echo e(asset('storage/'.$foto->path)); ?>" class="d-block w-100" alt="Foto <?php echo e($i+1); ?>">
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#anuncioCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#anuncioCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon"></span>
        </button>
      </div>

      
      <h2 class="mt-3"><?php echo e($anuncio->titulo); ?></h2>
      <h4 class="text-danger">R$ <?php echo e(number_format($anuncio->preco, 2, ',', '.')); ?></h4>
      <p><i class="bi bi-geo-alt-fill"></i> <?php echo e($anuncio->cidade); ?> - <?php echo e($anuncio->estado); ?></p>
      <ul class="list-inline">
        <li class="list-inline-item"><i class="bi bi-speedometer2"></i> <?php echo e($anuncio->km); ?> km</li>
        <li class="list-inline-item"><i class="bi bi-calendar"></i> <?php echo e($anuncio->ano); ?></li>
        <li class="list-inline-item"><i class="bi bi-fuel-pump"></i> <?php echo e($anuncio->combustivel); ?></li>
      </ul>

      
      <div class="mt-4">
        <iframe 
          src="https://www.google.com/maps?q=<?php echo e($anuncio->lat); ?>,<?php echo e($anuncio->lng); ?>&output=embed" 
          width="100%" height="300" style="border:0;" allowfullscreen=""
        ></iframe>
      </div>
    </div>

    
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <img src="<?php echo e(asset('storage/'.$anuncio->user->avatar)); ?>" class="rounded-circle mb-2" width="80">
          <h5><?php echo e($anuncio->user->name); ?></h5>
          <a href="tel:<?php echo e($anuncio->user->phone); ?>" class="btn btn-outline-primary btn-sm w-100 mb-2">
            <i class="bi bi-telephone-fill"></i> Ligar
          </a>
          <a href="#" class="btn btn-primary btn-sm w-100">
            <i class="bi bi-chat-dots-fill"></i> Chat
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/anuncios/search/show.blade.php ENDPATH**/ ?>
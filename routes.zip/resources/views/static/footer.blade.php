<div class="footer">
    <p>&copy; 2025 RetroRides - Todos os direitos reservados</p>
</div>
    
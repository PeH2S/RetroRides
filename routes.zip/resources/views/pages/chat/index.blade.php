{{-- resources/views/pages/chat/index.blade.php --}}
@extends('static.layoutHome') {{-- ou o layout que você use no dashboard --}}
@section('main')
  <div class="container mt-4">
    <h2>Chat</h2>
    <p>Ainda não implementado. Aqui vai a lista de conversas do usuário.</p>
  </div>
@endsection

<?php $__env->startSection('main'); ?>
  <div class="container mt-4">
    <h2>Favoritos</h2>
    <p>Ainda não implementado.</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/favoritos/index.blade.php ENDPATH**/ ?>



<?php $__env->startSection('main'); ?>
<div class="container mt-4">
    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary mb-3">
        &larr; Voltar
    </a>

    <div class="bg-white p-4 rounded shadow-sm w-100" style="max-width: 600px; margin: 0 auto;">
        <h4 class="text-center mb-4">Detalhes do Usuário</h4>

        <div class="mb-3">
            <label class="form-label"><strong>Nome:</strong></label>
            <div class="form-control-plaintext"><?php echo e($user->name); ?></div>
        </div>

        <div class="mb-3">
            <label class="form-label"><strong>E-mail:</strong></label>
            <div class="form-control-plaintext"><?php echo e($user->email); ?></div>
        </div>

        <div class="mb-4">
            <label class="form-label"><strong>Data de Cadastro:</strong></label>
            <div class="form-control-plaintext"><?php echo e($user->created_at->format('d/m/Y H:i')); ?></div>
        </div>

        <div class="d-grid">
            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-danger">
                Editar
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/users/show.blade.php ENDPATH**/ ?>
 

<?php $__env->startSection('main'); ?>
<div class="container-fluid">
    <div class="row">
        
        <div class="col-md-3 bg-light border-end vh-100 p-0">
            <div class="text-center py-4">
                
                <div class="rounded-circle bg-secondary text-white mx-auto mb-2"
                     style="width: 60px; height: 60px; line-height: 60px; font-size: 24px;">
                    <?php echo e(strtoupper(Auth::user()->name[0])); ?>

                </div>
                
                <div>
                    <strong class="d-block"><?php echo e(Auth::user()->name); ?></strong>
                    <small class="text-muted"><?php echo e(Auth::user()->email); ?></small>
                </div>
            </div>

            <nav class="nav flex-column px-2">
                
                <a href="<?php echo e(route('anuncios-carros')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('anuncios-carros')): ?> active <?php endif; ?>">
                    <i class="bi bi-search me-2"></i>
                    Buscar veículo
                </a>

                <a href="<?php echo e(route('anunciar')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('anunciar')): ?> active <?php endif; ?>">
                    <i class="bi bi-cash-stack me-2"></i>
                    Vender meu veículo
                </a>

                <a href="<?php echo e(route('anuncios.index')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('anuncios.*')): ?> active <?php endif; ?>">
                    <i class="bi bi-megaphone me-2"></i>
                    Meus anúncios
                </a>

                <a href="<?php echo e(route('chat.index')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('chat.*')): ?> active <?php endif; ?>">
                    <i class="bi bi-chat-dots me-2"></i>
                    Chat
                </a>

                <a href="<?php echo e(route('favoritos.index')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('favoritos.*')): ?> active <?php endif; ?>">
                    <i class="bi bi-heart me-2"></i>
                    Favoritos
                </a>

                <a href="<?php echo e(route('alertas.index')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('alertas.*')): ?> active <?php endif; ?>">
                    <i class="bi bi-bell me-2"></i>
                    Alertas
                </a>

                <a href="<?php echo e(route('financiamento.index')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('financiamento.*')): ?> active <?php endif; ?>">
                    <i class="bi bi-currency-dollar me-2"></i>
                    Financiamento
                </a>

                
                <a href="<?php echo e(route('minha-conta')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('minha-conta')): ?> active <?php endif; ?>">
                    <i class="bi bi-person me-2"></i>
                    Minha conta
                </a>
                <div class="ms-4 mb-2">
                    <a href="<?php echo e(route('minha-conta')); ?>"
                       class="nav-link py-1 <?php if(request()->routeIs('minha-conta')): ?> text-decoration-underline <?php endif; ?>">
                        Editar dados
                    </a>
                    <a href="<?php echo e(route('minha-conta')); ?>#personalizacao"
                       class="nav-link py-1 <?php if(request()->routeIs('minha-conta') && request()->getFragment() === 'personalizacao'): ?> text-decoration-underline <?php endif; ?>">
                        Personalização e dados
                    </a>
                </div>

                <a href="<?php echo e(route('ajuda')); ?>"
                   class="nav-link d-flex align-items-center <?php if(request()->routeIs('ajuda')): ?> active <?php endif; ?>">
                    <i class="bi bi-question-circle me-2"></i>
                    Ajuda
                </a>

                
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="mt-3 px-2">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                            class="btn btn-outline-danger w-100 d-flex align-items-center justify-content-center">
                        <i class="bi bi-box-arrow-right me-2"></i>
                        Sair
                    </button>
                </form>
            </nav>
        </div>
        

        
        <div class="col-md-9 p-4">
            
            <h2 class="mb-4">Minha conta</h2>

            <div class="row">
                
                <div class="col-lg-6 mb-4">
                    <div class="bg-white p-4 rounded shadow-sm">
                        <h5 class="mb-3">Meus dados</h5>
                        <form action="<?php echo e(route('minha-conta.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            
                            <div class="mb-3">
                                <label for="email" class="form-label">E-mail*</label>
                                <input type="email"
                                       id="email"
                                       name="email"
                                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('email', Auth::user()->email)); ?>"
                                       required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Nome completo*</label>
                                <input type="text"
                                       id="name"
                                       name="name"
                                       class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('name', Auth::user()->name)); ?>"
                                       required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="gender" class="form-label">Gênero*</label>
                                <select id="gender"
                                        name="gender"
                                        class="form-select <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        required>
                                    <option disabled selected>Selecione</option>
                                    <option value="masculino" <?php if(old('gender', Auth::user()->gender) === 'masculino'): ?> selected <?php endif; ?>>Masculino</option>
                                    <option value="feminino"  <?php if(old('gender', Auth::user()->gender) === 'feminino'): ?>  selected <?php endif; ?>>Feminino</option>
                                    <option value="outro"      <?php if(old('gender', Auth::user()->gender) === 'outro'): ?>      selected <?php endif; ?>>Outro</option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="birthdate" class="form-label">Data de nascimento*</label>
                                <input type="date"
                                       id="birthdate"
                                       name="birthdate"
                                       class="form-control <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('birthdate', Auth::user()->birthdate?->format('Y-m-d'))); ?>"
                                       required>
                                <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="cpf" class="form-label">CPF*</label>
                                <input type="text"
                                       id="cpf"
                                       name="cpf"
                                       class="form-control <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('cpf', Auth::user()->cpf)); ?>"
                                       required>
                                <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <p class="small text-muted mt-3">
                                Ao prosseguir, declaro ter ciência de que este cadastro é somente para maiores de 18 anos.
                            </p>
                        </form>
                    </div>
                </div>

                
                <div class="col-lg-6 mb-4">
                    <div class="bg-white p-4 rounded shadow-sm">
                        <h5 class="mb-3">Meu endereço e contato</h5>
                        <form action="<?php echo e(route('minha-conta.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            
                            <div class="mb-3">
                                <label for="cep" class="form-label">CEP*</label>
                                <input type="text"
                                       id="cep"
                                       name="cep"
                                       class="form-control <?php $__errorArgs = ['cep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('cep', Auth::user()->address->cep ?? '')); ?>"
                                       placeholder="00000-000"
                                       required>
                                <?php $__errorArgs = ['cep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="row g-2 mb-3">
                                <div class="col-md-4">
                                    <label for="state" class="form-label">Estado*</label>
                                    <input type="text"
                                           id="state"
                                           name="state"
                                           class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           value="<?php echo e(old('state', Auth::user()->address->state ?? '')); ?>"
                                           placeholder="SP"
                                           required>
                                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-8">
                                    <label for="city" class="form-label">Cidade*</label>
                                    <input type="text"
                                           id="city"
                                           name="city"
                                           class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           value="<?php echo e(old('city', Auth::user()->address->city ?? '')); ?>"
                                           placeholder="São Paulo"
                                           required>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="mb-3 d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <label for="phone" class="form-label">Telefone*</label>
                                    <input type="text"
                                           id="phone"
                                           name="phone"
                                           class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           value="<?php echo e(old('phone', Auth::user()->phone)); ?>"
                                           required>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="button"
                                        class="btn btn-link text-danger ms-2 mt-4 p-0"
                                        onclick="document.getElementById('phone').removeAttribute('disabled');">
                                    Editar
                                </button>
                            </div>

                            
                            <div class="form-check mb-3">
                                <input class="form-check-input"
                                       type="checkbox"
                                       id="show_phone"
                                       name="show_phone"
                                       <?php echo e(old('show_phone', Auth::user()->show_phone) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="show_phone">
                                    Exibir meu telefone no anúncio
                                </label>
                            </div>

                            <small class="text-muted">
                                Uma vez alterado o número de celular, a próxima alteração só poderá ser feita após 24 horas.
                            </small>
                        </form>
                    </div>
                </div>
            </div>

            
            <div class="text-end">
                <form action="<?php echo e(route('minha-conta.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger px-4">
                        Salvar alterações
                    </button>
                </form>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>
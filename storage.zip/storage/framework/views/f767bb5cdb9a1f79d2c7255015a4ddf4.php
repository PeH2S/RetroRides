<?php $__env->startSection('main'); ?>

<div class="container mt-4">
    
    <?php echo $__env->make('pages.anuncios.partials.steps', ['step' => 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Formulário Centralizado e Estreito -->
    <div class="d-flex justify-content-center">
        <div class="bg-white p-4 rounded shadow-sm w-100" style="max-width: 600px;">
            <h4 class="text-center mb-4">Preencha os dados do veículo</h4>

            
            <form id="form-anuncio" action="<?php echo e(route('anuncio.step1Post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    
                    <div class="col-12">
                        <label for="titulo" class="form-label">Título do Anúncio*</label>
                        <input type="text"
                               class="form-control <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="titulo"
                               name="titulo"
                               value="<?php echo e(old('titulo')); ?>"
                               placeholder="Ex.: Volkswagen Golf 2018 1.4 TSI"
                               required>
                        <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-12">
                        <label for="descricao" class="form-label">Descrição*</label>
                        <textarea class="form-control <?php $__errorArgs = ['descricao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  id="descricao"
                                  name="descricao"
                                  rows="4"
                                  placeholder="Detalhe aspectos como estado de conservação, número de proprietários, opcionais, histórico de revisões etc."
                                  required><?php echo e(old('descricao')); ?></textarea>
                        <?php $__errorArgs = ['descricao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-12">
                        <label for="marca" class="form-label">Marca*</label>
                        <select class="form-select <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="marca"
                                name="marca"
                                required>
                            <option selected disabled>Carregando...</option>
                        </select>
                        <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-12">
                        <label for="modelo" class="form-label">Modelo*</label>
                        <select class="form-select <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="modelo"
                                name="modelo"
                                required
                                disabled>
                            <option selected disabled>Selecione uma marca primeiro</option>
                        </select>
                        <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="ano_modelo" class="form-label">Ano do Modelo*</label>
                            <select class="form-select <?php $__errorArgs = ['ano_modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="ano_modelo"
                                    name="ano_modelo"
                                    required
                                    disabled>
                                <option selected disabled>Selecione o modelo</option>
                            </select>
                            <?php $__errorArgs = ['ano_modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6">
                            <label for="ano_fabricacao" class="form-label">Ano de Fabricação*</label>
                            <select class="form-select <?php $__errorArgs = ['ano_fabricacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="ano_fabricacao"
                                    name="ano_fabricacao"
                                    required
                                    disabled>
                                <option selected disabled>Selecione o modelo</option>
                            </select>
                            <?php $__errorArgs = ['ano_fabricacao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <label for="combustivel_visivel" class="form-label">Combustível*</label>
                        <input type="text"
                               class="form-control"
                               id="combustivel_visivel"
                               readonly>
                        <input type="hidden" name="combustivel" id="combustivel">
                        <?php $__errorArgs = ['combustivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-12">
                        <label for="cor" class="form-label">Cor*</label>
                        <select class="form-select <?php $__errorArgs = ['cor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="cor"
                                name="cor"
                                required>
                            <option selected disabled>Selecione</option>
                            <option>Branco</option>
                            <option>Preto</option>
                            <option>Prata</option>
                            <option>Azul</option>
                            <option>Vermelho</option>
                        </select>
                        <?php $__errorArgs = ['cor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input"
                                   type="checkbox"
                                   id="blindado"
                                   name="blindado">
                            <label class="form-check-label" for="blindado">Blindado</label>
                        </div>
                    </div>

                    
                    <div class="alert alert-warning mt-3">
                        <i class="bi bi-info-circle"></i>
                        Não será possível editar esses dados depois.
                        <strong>Revise com atenção.</strong>
                    </div>

                    
                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(route('anunciar')); ?>" class="btn btn-outline-secondary">
                            &larr; Voltar
                        </a>
                        <button type="submit" class="btn btn-danger">
                            Continuar &rarr;
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="<?php echo e(asset('js/ad/adCreate.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/anuncios/cars/create/step1.blade.php ENDPATH**/ ?>
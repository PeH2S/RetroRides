<div class="footer">
    <p>&copy; 2025 RetroRides - Todos os direitos reservados</p>
</div>
<?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/static/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('main'); ?>
<!-- Banners -->
<nav>
    <?php echo $__env->make('static.banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</nav>

<!-- Barra de Busca -->
<div class="container mt-5">
    <?php echo $__env->make('static.searchBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>


<div class="row" >
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="<?php echo e(url('images/OIP.jpg')); ?>" class="card-img-top" alt="Carro Vintage">
            <div class="card-body">
                <h5 class="card-title">Chevrolet Opala 1975</h5>
                <p class="card-text">R$ 50.000,00 - São Paulo/SP</p>
                <a href="#" class="btn btn-custom">Ver Detalhes</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="<?php echo e(url('images/OIP-1.jpg')); ?>" class="card-img-top" alt="Carro Vintage">
            <div class="card-body">
                <h5 class="card-title">Ford Maverick 1973</h5>
                <p class="card-text">R$ 80.000,00 - Rio de Janeiro/RJ</p>
                <a href="#" class="btn btn-custom">Ver Detalhes</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="<?php echo e(url('images/OIP-2.jpg')); ?>" class="card-img-top" alt="Carro Vintage">
            <div class="card-body">
                <h5 class="card-title">Volkswagen Karmann-Ghia 1970</h5>
                <p class="card-text">R$ 65.000,00 - Belo Horizonte/MG</p>
                <a href="#" class="btn btn-custom">Ver Detalhes</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('static.layoutHome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Usuario\Desktop\retrorides\RetroRides\resources\views/pages/home.blade.php ENDPATH**/ ?>
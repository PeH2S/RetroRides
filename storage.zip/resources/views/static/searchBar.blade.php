<div class="search-bar text-center">
    <h3>Encontre seu carro dos sonhos</h3>
    <input type="text" class="form-control mt-3" placeholder="Busque por marca, modelo, ano...">
</div>

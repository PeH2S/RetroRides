@extends('static.layoutHome')

@section('main')
<!-- Banners -->
<nav>
    @include('static.banner')
</nav>

<!-- Barra de Busca -->
<div class="container mt-5">
    @include('static.searchBar')
</div>


<div class="row" >
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="{{ url('images/OIP.jpg') }}" class="card-img-top" alt="Carro Vintage">
            <div class="card-body">
                <h5 class="card-title">Chevrolet Opala 1975</h5>
                <p class="card-text">R$ 50.000,00 - São Paulo/SP</p>
                <a href="#" class="btn btn-custom">Ver Detalhes</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="{{ url('images/OIP-1.jpg') }}" class="card-img-top" alt="Carro Vintage">
            <div class="card-body">
                <h5 class="card-title">Ford Maverick 1973</h5>
                <p class="card-text">R$ 80.000,00 - Rio de Janeiro/RJ</p>
                <a href="#" class="btn btn-custom">Ver Detalhes</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card">
            <img src="{{ url('images/OIP-2.jpg') }}" class="card-img-top" alt="Carro Vintage">
            <div class="card-body">
                <h5 class="card-title">Volkswagen Karmann-Ghia 1970</h5>
                <p class="card-text">R$ 65.000,00 - Belo Horizonte/MG</p>
                <a href="#" class="btn btn-custom">Ver Detalhes</a>
            </div>
        </div>
    </div>
</div>

@endsection
